package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge;

import java.util.HashSet;

public abstract class Beobachtbar
{
	HashSet<Beobachter> _beobachter = new HashSet<Beobachter>();
	
	
	
	public void fuegeBeobachterHinzu(Beobachter b)
	{
		_beobachter.add(b);
	}

	
	public void entferneBeobachter(Beobachter b )
	{
	    _beobachter.remove(b);
	}

	protected void meldeAenderung()
	{
	    for(Beobachter b : _beobachter)
	    {
	        b.beachteAenderung(this);
	    }
	}
}
