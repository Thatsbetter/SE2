package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge;

public interface Beobachter
{
    void beachteAenderung(Object o);
}
